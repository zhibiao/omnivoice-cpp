#[[
	Build options:
	* Standard BUILD_SHARED_LIBS is supported and sets HTTPLIB_SHARED default value.
	* HTTPLIB_USE_OPENSSL_IF_AVAILABLE (default on)
	* HTTPLIB_USE_WOLFSSL_IF_AVAILABLE (default off)
	* HTTPLIB_USE_MBEDTLS_IF_AVAILABLE (default off)
	* HTTPLIB_USE_ZLIB_IF_AVAILABLE (default on)
	* HTTPLIB_USE_BROTLI_IF_AVAILABLE (default on)
	* HTTPLIB_USE_ZSTD_IF_AVAILABLE (default on)
	* HTTPLIB_BUILD_MODULES (default off)
	* HTTPLIB_REQUIRE_OPENSSL (default off)
	* HTTPLIB_REQUIRE_WOLFSSL (default off)
	* HTTPLIB_REQUIRE_MBEDTLS (default off)
	* HTTPLIB_REQUIRE_ZLIB (default off)
	* HTTPLIB_REQUIRE_BROTLI (default off)
	* HTTPLIB_REQUIRE_ZSTD (default off)
	* HTTPLIB_DISABLE_MACOSX_AUTOMATIC_ROOT_CERTIFICATES (default off)
	* HTTPLIB_USE_NON_BLOCKING_GETADDRINFO (default on when supported)
	* HTTPLIB_COMPILE (default off)
	* HTTPLIB_INSTALL (default on)
	* HTTPLIB_SHARED (default off) builds as a shared library (if HTTPLIB_COMPILE is ON)
	* HTTPLIB_TEST (default off)
	* BROTLI_USE_STATIC_LIBS - tells Cmake to use the static Brotli libs (only works if you have them installed).
	* OPENSSL_USE_STATIC_LIBS - tells Cmake to use the static OpenSSL libs (only works if you have them installed).

	-------------------------------------------------------------------------------

	After installation with Cmake, a find_package(httplib COMPONENTS OpenSSL wolfssl MbedTLS ZLIB Brotli zstd) is available.
	This creates a httplib::httplib target (if found and if listed components are supported).
	It can be linked like so:

	target_link_libraries(your_exe httplib::httplib)

	The following will build & install for later use.

	Linux/macOS:

	mkdir -p build
	cd build
	cmake -DCMAKE_BUILD_TYPE=Release ..
	sudo cmake --build . --target install

	Windows:

	mkdir build
	cd build
	cmake ..
	runas /user:Administrator "cmake --build . --config Release --target install"

	-------------------------------------------------------------------------------

	These variables are available after you run find_package(httplib)
	* HTTPLIB_HEADER_PATH - this is the full path to the installed header (e.g. /usr/include/httplib.h).
	* HTTPLIB_IS_USING_OPENSSL - a bool for if OpenSSL support is enabled.
	* HTTPLIB_IS_USING_WOLFSSL - a bool for if wolfSSL support is enabled.
	* HTTPLIB_IS_USING_MBEDTLS - a bool for if MbedTLS support is enabled.
	* HTTPLIB_IS_USING_ZLIB - a bool for if ZLIB support is enabled.
	* HTTPLIB_IS_USING_BROTLI - a bool for if Brotli support is enabled.
	* HTTPLIB_IS_USING_ZSTD - a bool for if ZSTD support is enabled.
	* HTTPLIB_IS_USING_MACOSX_AUTOMATIC_ROOT_CERTIFICATES - a bool for if support of loading system certs from the Apple Keychain is enabled.
	* HTTPLIB_IS_USING_NON_BLOCKING_GETADDRINFO - a bool for if nonblocking getaddrinfo is enabled.
	* HTTPLIB_IS_COMPILED - a bool for if the library is compiled, or otherwise header-only.
	* HTTPLIB_INCLUDE_DIR - the root path to httplib's header (e.g. /usr/include).
	* HTTPLIB_LIBRARY - the full path to the library if compiled (e.g. /usr/lib/libhttplib.so).
	* httplib_VERSION or HTTPLIB_VERSION - the project's version string.
	* HTTPLIB_FOUND - a bool for if the target was found.

	Want to use precompiled headers (Cmake feature since v3.16)?
	It's as simple as doing the following (before linking):

	target_precompile_headers(httplib::httplib INTERFACE "${HTTPLIB_HEADER_PATH}")

	-------------------------------------------------------------------------------

	ARCH_INDEPENDENT option of write_basic_package_version_file() requires Cmake v3.14
]]
cmake_minimum_required(VERSION 3.14.0 FATAL_ERROR)

# Get the CPPHTTPLIB_VERSION value and use it as a version
# This gets the string with the CPPHTTPLIB_VERSION value from the header.
# This is so the maintainer doesn't actually need to update this manually.
file(STRINGS httplib.h _raw_version_string REGEX "CPPHTTPLIB_VERSION \"([0-9]+\\.[0-9]+\\.[0-9]+)\"")

# Extracts just the version string itself from the whole string contained in _raw_version_string
# since _raw_version_string would contain the entire line of code where it found the version string
string(REGEX MATCH "([0-9]+\\.?)+" _httplib_version "${_raw_version_string}")

project(httplib
	VERSION ${_httplib_version}
	LANGUAGES CXX
	DESCRIPTION "A C++ header-only HTTP/HTTPS server and client library."
	HOMEPAGE_URL "https://github.com/yhirose/cpp-httplib"
)

# Change as needed to set an OpenSSL minimum version.
# This is used in the installed Cmake config file.
set(_HTTPLIB_OPENSSL_MIN_VER "3.0.0")

# Lets you disable C++ exception during CMake configure time.
# The value is used in the install CMake config file.
option(HTTPLIB_NO_EXCEPTIONS "Disable the use of C++ exceptions" OFF)
# Allow for a build to require OpenSSL to pass, instead of just being optional
option(HTTPLIB_REQUIRE_OPENSSL "Requires OpenSSL to be found & linked, or fails build." OFF)
option(HTTPLIB_REQUIRE_WOLFSSL "Requires wolfSSL to be found & linked, or fails build." OFF)
option(HTTPLIB_REQUIRE_MBEDTLS "Requires MbedTLS to be found & linked, or fails build." OFF)
option(HTTPLIB_REQUIRE_ZLIB "Requires ZLIB to be found & linked, or fails build." OFF)
# Allow for a build to casually enable OpenSSL/ZLIB support, but silently continue if not found.
# Make these options so their automatic use can be specifically disabled (as needed)
option(HTTPLIB_USE_OPENSSL_IF_AVAILABLE "Uses OpenSSL (if available) to enable HTTPS support." ON)
option(HTTPLIB_USE_WOLFSSL_IF_AVAILABLE "Uses wolfSSL (if available) to enable HTTPS support." OFF)
option(HTTPLIB_USE_MBEDTLS_IF_AVAILABLE "Uses MbedTLS (if available) to enable HTTPS support." OFF)
option(HTTPLIB_USE_ZLIB_IF_AVAILABLE "Uses ZLIB (if available) to enable Zlib compression support." ON)
# Lets you compile the program as a regular library instead of header-only
option(HTTPLIB_COMPILE "If ON, uses a Python script to split the header into a compilable header & source file (requires Python v3)." OFF)
# Lets you disable the installation (useful when fetched from another CMake project)
option(HTTPLIB_INSTALL "Enables the installation target" ON)
option(HTTPLIB_TEST "Enables testing and builds tests" OFF)
option(HTTPLIB_REQUIRE_BROTLI "Requires Brotli to be found & linked, or fails build." OFF)
option(HTTPLIB_USE_BROTLI_IF_AVAILABLE "Uses Brotli (if available) to enable Brotli decompression support." ON)
option(HTTPLIB_DISABLE_MACOSX_AUTOMATIC_ROOT_CERTIFICATES "Disable loading system certs from the Apple Keychain on macOS." OFF)
option(HTTPLIB_USE_NON_BLOCKING_GETADDRINFO "Enables the non-blocking alternatives for getaddrinfo." ON)
option(HTTPLIB_REQUIRE_ZSTD "Requires ZSTD to be found & linked, or fails build." OFF)
option(HTTPLIB_USE_ZSTD_IF_AVAILABLE "Uses ZSTD (if available) to enable zstd support." ON)
# C++20 modules support requires CMake 3.28 or later
if(CMAKE_VERSION VERSION_GREATER_EQUAL "3.28")
	option(HTTPLIB_BUILD_MODULES "Build httplib modules (requires HTTPLIB_COMPILE to be ON)." OFF)
else()
	set(HTTPLIB_BUILD_MODULES OFF CACHE INTERNAL "Build httplib modules disabled (requires CMake 3.28+)" FORCE)
	if(DEFINED CACHE{HTTPLIB_BUILD_MODULES} AND HTTPLIB_BUILD_MODULES)
		message(WARNING "HTTPLIB_BUILD_MODULES requires CMake 3.28 or later. Current version is ${CMAKE_VERSION}. Modules support has been disabled.")
	endif()
endif()

# Incompatibility between TLS libraries
set(TLS_LIBRARIES_USED_TMP 0)

foreach(tls_library OPENSSL WOLFSSL MBEDTLS)
	set(TLS_REQUIRED ${HTTPLIB_REQUIRE_${tls_library}})
	set(TLS_IF_AVAILABLE ${HTTPLIB_USE_${tls_library}_IF_AVAILABLE})

	if(TLS_REQUIRED OR TLS_IF_AVAILABLE)
		math(EXPR TLS_LIBRARIES_USED_TMP "${TLS_LIBRARIES_USED_TMP} + 1")
	endif()
endforeach()

if(TLS_LIBRARIES_USED_TMP GREATER 1)
	message(FATAL_ERROR "TLS libraries are mutually exclusive.")
endif()

# Defaults to static library but respects standard BUILD_SHARED_LIBS if set
include(CMakeDependentOption)
cmake_dependent_option(HTTPLIB_SHARED "Build the library as a shared library instead of static. Has no effect if using header-only."
	"${BUILD_SHARED_LIBS}" HTTPLIB_COMPILE OFF
)
if(HTTPLIB_SHARED)
	set(HTTPLIB_LIB_TYPE SHARED)
	if(WIN32)
		# Necessary for Windows if building shared libs
		# See https://stackoverflow.com/a/40743080
		set(CMAKE_WINDOWS_EXPORT_ALL_SYMBOLS ON)
	endif()
else()
	set(HTTPLIB_LIB_TYPE STATIC)
endif()

if(CMAKE_SYSTEM_NAME MATCHES "Windows")
	if(CMAKE_SYSTEM_VERSION)
		if(${CMAKE_SYSTEM_VERSION} VERSION_LESS "10.0.0")
			message(WARNING "Windows ${CMAKE_SYSTEM_VERSION} or lower is not supported. Please use Windows 10 or later.")
		endif()
	else()
		set(CMAKE_SYSTEM_VERSION "10.0.19041.0")
		message(WARNING "The target is Windows but CMAKE_SYSTEM_VERSION is not set, the default system version is set to Windows 10.")
	endif()
endif()

# Set some variables that are used in-tree and while building based on our options
set(HTTPLIB_IS_COMPILED ${HTTPLIB_COMPILE})
set(HTTPLIB_IS_USING_MACOSX_AUTOMATIC_ROOT_CERTIFICATES TRUE)
if(HTTPLIB_DISABLE_MACOSX_AUTOMATIC_ROOT_CERTIFICATES)
	set(HTTPLIB_IS_USING_MACOSX_AUTOMATIC_ROOT_CERTIFICATES FALSE)
endif()
set(HTTPLIB_IS_USING_NON_BLOCKING_GETADDRINFO ${HTTPLIB_USE_NON_BLOCKING_GETADDRINFO})
if(HTTPLIB_IS_USING_NON_BLOCKING_GETADDRINFO AND WIN32)
	include(CheckCXXSymbolExists)

	set(_httplib_cmake_required_definitions ${CMAKE_REQUIRED_DEFINITIONS})
	set(_httplib_cmake_required_libraries ${CMAKE_REQUIRED_LIBRARIES})
	list(APPEND CMAKE_REQUIRED_DEFINITIONS -D_WIN32_WINNT=0x0A00)
	list(APPEND CMAKE_REQUIRED_LIBRARIES ws2_32)
	check_cxx_symbol_exists(GetAddrInfoExCancel "winsock2.h;ws2tcpip.h" HTTPLIB_HAVE_GETADDRINFOEXCANCEL)
	set(CMAKE_REQUIRED_DEFINITIONS ${_httplib_cmake_required_definitions})
	set(CMAKE_REQUIRED_LIBRARIES ${_httplib_cmake_required_libraries})
	unset(_httplib_cmake_required_definitions)
	unset(_httplib_cmake_required_libraries)

	if(NOT HTTPLIB_HAVE_GETADDRINFOEXCANCEL)
		set(HTTPLIB_IS_USING_NON_BLOCKING_GETADDRINFO FALSE)
		message(WARNING "GetAddrInfoExCancel is unavailable; disabling non-blocking getaddrinfo.")
	endif()
endif()

# Threads needed for <thread> on some systems, and for <pthread.h> on Linux
set(THREADS_PREFER_PTHREAD_FLAG TRUE)
find_package(Threads REQUIRED)
# Since Cmake v3.11, Crypto & SSL became optional when not specified as COMPONENTS.
if(HTTPLIB_REQUIRE_OPENSSL)
	find_package(OpenSSL ${_HTTPLIB_OPENSSL_MIN_VER} COMPONENTS Crypto SSL REQUIRED)
	set(HTTPLIB_IS_USING_OPENSSL TRUE)
elseif(HTTPLIB_USE_OPENSSL_IF_AVAILABLE)
	find_package(OpenSSL ${_HTTPLIB_OPENSSL_MIN_VER} COMPONENTS Crypto SSL QUIET)
	# Avoid a rare circumstance of not finding all components but the end-user did their
	# own call for OpenSSL, which might trick us into thinking we'd otherwise have what we wanted
	if (TARGET OpenSSL::SSL AND TARGET OpenSSL::Crypto)
		set(HTTPLIB_IS_USING_OPENSSL ${OPENSSL_FOUND})
	else()
		set(HTTPLIB_IS_USING_OPENSSL FALSE)
	endif()
endif()

if(HTTPLIB_REQUIRE_WOLFSSL)
	find_package(wolfssl REQUIRED)
	set(HTTPLIB_IS_USING_WOLFSSL TRUE)
elseif(HTTPLIB_USE_WOLFSSL_IF_AVAILABLE)
	find_package(wolfssl QUIET)
	set(HTTPLIB_IS_USING_WOLFSSL ${wolfssl_FOUND})
endif()

if(HTTPLIB_REQUIRE_MBEDTLS)
	find_package(MbedTLS REQUIRED)
	set(HTTPLIB_IS_USING_MBEDTLS TRUE)
elseif(HTTPLIB_USE_MBEDTLS_IF_AVAILABLE)
	find_package(MbedTLS QUIET)
	set(HTTPLIB_IS_USING_MBEDTLS ${MbedTLS_FOUND})
endif()

if(HTTPLIB_REQUIRE_ZLIB)
	find_package(ZLIB REQUIRED)
	set(HTTPLIB_IS_USING_ZLIB TRUE)
elseif(HTTPLIB_USE_ZLIB_IF_AVAILABLE)
	find_package(ZLIB QUIET)
	# FindZLIB doesn't have a ZLIB_FOUND variable, so check the target.
	if(TARGET ZLIB::ZLIB)
		set(HTTPLIB_IS_USING_ZLIB TRUE)
	endif()
endif()

# Adds our cmake folder to the search path for find_package
# This is so we can use our custom FindBrotli.cmake
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/cmake")
if(HTTPLIB_REQUIRE_BROTLI)
	find_package(Brotli COMPONENTS encoder decoder common REQUIRED)
	set(HTTPLIB_IS_USING_BROTLI TRUE)
elseif(HTTPLIB_USE_BROTLI_IF_AVAILABLE)
	find_package(Brotli COMPONENTS encoder decoder common QUIET)
	set(HTTPLIB_IS_USING_BROTLI ${Brotli_FOUND})
endif()

# NOTE:
# zstd < 1.5.6 does not provide the CMake imported target `zstd::libzstd`.
# Older versions must be consumed via their pkg-config file.
if(HTTPLIB_REQUIRE_ZSTD)
	if (NOT TARGET zstd::libzstd)
		find_package(zstd 1.5.6 CONFIG)
		if(NOT zstd_FOUND)
			find_package(PkgConfig REQUIRED)
			pkg_check_modules(zstd REQUIRED IMPORTED_TARGET libzstd)
			add_library(zstd::libzstd ALIAS PkgConfig::zstd)
		endif()
	endif()
	set(HTTPLIB_IS_USING_ZSTD TRUE)
elseif(HTTPLIB_USE_ZSTD_IF_AVAILABLE)
	if (TARGET zstd::libzstd)
		set(HTTPLIB_IS_USING_ZSTD TRUE)
	else()
		find_package(zstd 1.5.6 CONFIG QUIET)
		if(NOT zstd_FOUND)
			find_package(PkgConfig QUIET)
			if(PKG_CONFIG_FOUND)
				pkg_check_modules(zstd QUIET IMPORTED_TARGET libzstd)

				if(TARGET PkgConfig::zstd)
					add_library(zstd::libzstd ALIAS PkgConfig::zstd)
				endif()
			endif()
		endif()
		# Both find_package and PkgConf set a XXX_FOUND var
		set(HTTPLIB_IS_USING_ZSTD ${zstd_FOUND})
	endif()
endif()

# Used for default, common dirs that the end-user can change (if needed)
# like CMAKE_INSTALL_INCLUDEDIR or CMAKE_INSTALL_DATADIR
include(GNUInstallDirs)

if(HTTPLIB_COMPILE)
	# Put the split script into the build dir
	configure_file(split.py "${CMAKE_CURRENT_BINARY_DIR}/split.py"
		COPYONLY
	)
	# Needs to be in the same dir as the python script
	configure_file(httplib.h "${CMAKE_CURRENT_BINARY_DIR}/httplib.h"
		COPYONLY
	)

	# Used outside of this if-else
	set(_INTERFACE_OR_PUBLIC PUBLIC)
	# Brings in the Python3_EXECUTABLE path we can use.
	find_package(Python3 REQUIRED)
	# Actually split the file
	# Keeps the output in the build dir to not pollute the main dir
	execute_process(COMMAND ${Python3_EXECUTABLE} "${CMAKE_CURRENT_BINARY_DIR}/split.py"
		WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
		ERROR_VARIABLE _httplib_split_error
	)
	if(_httplib_split_error)
		message(FATAL_ERROR "Failed when trying to split cpp-httplib with the Python script.\n${_httplib_split_error}")
	endif()

	# If building modules, also generate the module file
	if(HTTPLIB_BUILD_MODULES)
		# Put the generate_module script into the build dir
		configure_file(generate_module.py "${CMAKE_CURRENT_BINARY_DIR}/generate_module.py"
			COPYONLY
		)
		# Generate the module file
		execute_process(COMMAND ${Python3_EXECUTABLE} "${CMAKE_CURRENT_BINARY_DIR}/generate_module.py"
			WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
			ERROR_VARIABLE _httplib_module_error
		)
		if(_httplib_module_error)
			message(FATAL_ERROR "Failed when trying to generate cpp-httplib module with the Python script.\n${_httplib_module_error}")
		endif()
	endif()

	# split.py puts output in "out"
	set(_httplib_build_includedir "${CMAKE_CURRENT_BINARY_DIR}/out")
	add_library(${PROJECT_NAME} ${HTTPLIB_LIB_TYPE} "${_httplib_build_includedir}/httplib.cc")
	target_sources(${PROJECT_NAME}
		PUBLIC
			$<BUILD_INTERFACE:${_httplib_build_includedir}/httplib.h>
			$<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}/httplib.h>
	)

	# Add C++20 module support if requested
	# Include from separate file to prevent parse errors on older CMake versions
	if(CMAKE_VERSION VERSION_GREATER_EQUAL "3.28")
		include(cmake/modules.cmake)
	endif()

	set_target_properties(${PROJECT_NAME}
		PROPERTIES
			VERSION ${${PROJECT_NAME}_VERSION}
			SOVERSION "${${PROJECT_NAME}_VERSION_MAJOR}.${${PROJECT_NAME}_VERSION_MINOR}"
			OUTPUT_NAME cpp-httplib
	)
else()
	# This is for header-only.
	set(_INTERFACE_OR_PUBLIC INTERFACE)
	add_library(${PROJECT_NAME} INTERFACE)
	set(_httplib_build_includedir "${CMAKE_CURRENT_SOURCE_DIR}")
endif()
# Lets you address the target with httplib::httplib
# Only useful if building in-tree, versus using it from an installation.
add_library(${PROJECT_NAME}::${PROJECT_NAME} ALIAS ${PROJECT_NAME})

# Require C++11, or C++20 if modules are enabled
if(HTTPLIB_BUILD_MODULES)
	target_compile_features(${PROJECT_NAME} ${_INTERFACE_OR_PUBLIC} cxx_std_20)
else()
	target_compile_features(${PROJECT_NAME} ${_INTERFACE_OR_PUBLIC} cxx_std_11)
endif()

target_include_directories(${PROJECT_NAME} SYSTEM ${_INTERFACE_OR_PUBLIC}
	$<BUILD_INTERFACE:${_httplib_build_includedir}>
	$<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>
)

target_link_libraries(${PROJECT_NAME} ${_INTERFACE_OR_PUBLIC}
		# Always require threads
		Threads::Threads
		# Needed for Windows libs on Mingw, as the pragma comment(lib, "xyz") aren't triggered.
		$<$<PLATFORM_ID:Windows>:ws2_32>
		$<$<PLATFORM_ID:Windows>:crypt32>
		# Needed for API from MacOS Security framework
		"$<$<AND:$<PLATFORM_ID:Darwin>,$<BOOL:${HTTPLIB_IS_USING_OPENSSL}>,$<BOOL:${HTTPLIB_IS_USING_MACOSX_AUTOMATIC_ROOT_CERTIFICATES}>>:-framework CFNetwork -framework CoreFoundation -framework Security>"
		# Needed for non-blocking getaddrinfo on MacOS
		"$<$<AND:$<PLATFORM_ID:Darwin>,$<BOOL:${HTTPLIB_IS_USING_NON_BLOCKING_GETADDRINFO}>>:-framework CFNetwork -framework CoreFoundation>"
		# Can't put multiple targets in a single generator expression or it bugs out.
		$<$<BOOL:${HTTPLIB_IS_USING_BROTLI}>:Brotli::common>
		$<$<BOOL:${HTTPLIB_IS_USING_BROTLI}>:Brotli::encoder>
		$<$<BOOL:${HTTPLIB_IS_USING_BROTLI}>:Brotli::decoder>
		$<$<BOOL:${HTTPLIB_IS_USING_ZLIB}>:ZLIB::ZLIB>
		$<$<BOOL:${HTTPLIB_IS_USING_ZSTD}>:zstd::libzstd>
		$<$<BOOL:${HTTPLIB_IS_USING_OPENSSL}>:OpenSSL::SSL>
		$<$<BOOL:${HTTPLIB_IS_USING_OPENSSL}>:OpenSSL::Crypto>
		$<$<BOOL:${HTTPLIB_IS_USING_WOLFSSL}>:wolfssl::wolfssl>
		$<$<BOOL:${HTTPLIB_IS_USING_MBEDTLS}>:MbedTLS::mbedtls>
)

# Set the definitions to enable optional features
target_compile_definitions(${PROJECT_NAME} ${_INTERFACE_OR_PUBLIC}
	$<$<BOOL:${HTTPLIB_NO_EXCEPTIONS}>:CPPHTTPLIB_NO_EXCEPTIONS>
	$<$<BOOL:${HTTPLIB_IS_USING_BROTLI}>:CPPHTTPLIB_BROTLI_SUPPORT>
	$<$<BOOL:${HTTPLIB_IS_USING_ZLIB}>:CPPHTTPLIB_ZLIB_SUPPORT>
	$<$<BOOL:${HTTPLIB_IS_USING_ZSTD}>:CPPHTTPLIB_ZSTD_SUPPORT>
	$<$<BOOL:${HTTPLIB_IS_USING_OPENSSL}>:CPPHTTPLIB_OPENSSL_SUPPORT>
	$<$<BOOL:${HTTPLIB_IS_USING_WOLFSSL}>:CPPHTTPLIB_WOLFSSL_SUPPORT>
	$<$<BOOL:${HTTPLIB_IS_USING_MBEDTLS}>:CPPHTTPLIB_MBEDTLS_SUPPORT>
	$<$<AND:$<PLATFORM_ID:Darwin>,$<BOOL:${HTTPLIB_DISABLE_MACOSX_AUTOMATIC_ROOT_CERTIFICATES}>>:CPPHTTPLIB_DISABLE_MACOSX_AUTOMATIC_ROOT_CERTIFICATES>
	$<$<BOOL:${HTTPLIB_IS_USING_NON_BLOCKING_GETADDRINFO}>:CPPHTTPLIB_USE_NON_BLOCKING_GETADDRINFO>
)

# CMake configuration files installation directory
set(_TARGET_INSTALL_CMAKEDIR "${CMAKE_INSTALL_LIBDIR}/cmake/${PROJECT_NAME}")

include(CMakePackageConfigHelpers)

# Configures the meta-file httplibConfig.cmake.in to replace variables with paths/values/etc.
configure_package_config_file("cmake/${PROJECT_NAME}Config.cmake.in"
	"${CMAKE_CURRENT_BINARY_DIR}/${PROJECT_NAME}Config.cmake"
	INSTALL_DESTINATION "${_TARGET_INSTALL_CMAKEDIR}"
	# Passes the includedir install path
	PATH_VARS CMAKE_INSTALL_FULL_INCLUDEDIR
)

if(HTTPLIB_COMPILE)
	write_basic_package_version_file("${PROJECT_NAME}ConfigVersion.cmake"
		# Example: if you find_package(httplib 0.5.4)
		# then anything >= 0.5.4 and < 0.6 is accepted
		COMPATIBILITY SameMinorVersion
	)
else()
	write_basic_package_version_file("${PROJECT_NAME}ConfigVersion.cmake"
		# Example: if you find_package(httplib 0.5.4)
		# then anything >= 0.5.4 and < 0.6 is accepted
		COMPATIBILITY SameMinorVersion
		# Tells Cmake that it's a header-only lib
		# Mildly useful for end-users :)
		ARCH_INDEPENDENT
	)
endif()

if(HTTPLIB_INSTALL)
	# Creates the export httplibTargets.cmake
	# This is strictly what holds compilation requirements
	# and linkage information (doesn't find deps though).
	if(HTTPLIB_BUILD_MODULES)
		install(TARGETS ${PROJECT_NAME} EXPORT httplibTargets FILE_SET CXX_MODULES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}/httplib/modules CXX_MODULES_BMI DESTINATION ${CMAKE_INSTALL_LIBDIR}/httplib/modules)
	else()
		install(TARGETS ${PROJECT_NAME} EXPORT httplibTargets)
	endif()

	install(FILES "${_httplib_build_includedir}/httplib.h" TYPE INCLUDE)

	install(FILES
		"${CMAKE_CURRENT_BINARY_DIR}/${PROJECT_NAME}Config.cmake"
		"${CMAKE_CURRENT_BINARY_DIR}/${PROJECT_NAME}ConfigVersion.cmake"
		# Install it so it can be used later by the httplibConfig.cmake file.
		# Put it in the same dir as our config file instead of a global path so we don't potentially stomp on other packages.
		"${CMAKE_CURRENT_SOURCE_DIR}/cmake/FindBrotli.cmake"
		DESTINATION ${_TARGET_INSTALL_CMAKEDIR}
	)

	# NOTE: This path changes depending on if it's on Windows or Linux
	install(EXPORT httplibTargets
		# Puts the targets into the httplib namespace
		# So this makes httplib::httplib linkable after doing find_package(httplib)
		NAMESPACE ${PROJECT_NAME}::
		DESTINATION ${_TARGET_INSTALL_CMAKEDIR}
	)

	# Install documentation & license
	# ex: /usr/share/doc/httplib/README.md and /usr/share/licenses/httplib/LICENSE
	install(FILES "README.md" DESTINATION "${CMAKE_INSTALL_DOCDIR}")
	install(FILES "LICENSE" DESTINATION "${CMAKE_INSTALL_DATADIR}/licenses/${PROJECT_NAME}")

	include(CPack)
endif()

if(HTTPLIB_BUILD_MODULES AND NOT HTTPLIB_COMPILE)
	message(FATAL_ERROR "HTTPLIB_BUILD_MODULES requires HTTPLIB_COMPILE to be ON.")
endif()

if(HTTPLIB_TEST)
	include(CTest)
	add_subdirectory(test)
endif()
